ALTER TABLE oidc_clients DROP COLUMN description;
