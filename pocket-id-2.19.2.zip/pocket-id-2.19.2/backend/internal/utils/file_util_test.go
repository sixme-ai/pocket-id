package utils

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestSplitFileName(t *testing.T) {
	t.Parallel()

	tests := []struct {
		fullName string
		wantName string
		wantExt  string
	}{
		{"background.jpg", "background", "jpg"},
		{"archive.tar.gz", "archive.tar", "gz"},
		{".gitignore", ".gitignore", ""},
		{"noext", "noext", ""},
		{"a.b.c", "a.b", "c"},
		{".hidden.ext", ".hidden", "ext"},
	}

	for _, tc := range tests {
		t.Run(tc.fullName, func(t *testing.T) {
			t.Parallel()
			name, ext := SplitFileName(tc.fullName)
			assert.Equal(t, tc.wantName, name)
			assert.Equal(t, tc.wantExt, ext)
		})
	}
}

func TestGetFileExtension(t *testing.T) {
	tests := []struct {
		name     string
		filename string
		want     string
	}{
		{
			name:     "Simple file with extension",
			filename: "document.pdf",
			want:     "pdf",
		},
		{
			name:     "File with path",
			filename: "/path/to/document.txt",
			want:     "txt",
		},
		{
			name:     "File with path (Windows style)",
			filename: "C:\\path\\to\\document.jpg",
			want:     "jpg",
		},
		{
			name:     "Multiple extensions",
			filename: "archive.tar.gz",
			want:     "gz",
		},
		{
			name:     "Hidden file with extension",
			filename: ".config.json",
			want:     "json",
		},
		{
			name:     "Filename with dots",
			filename: "version.1.2.3.txt",
			want:     "txt",
		},
		{
			name:     "File with uppercase extension",
			filename: "image.JPG",
			want:     "JPG",
		},
		{
			name:     "File without extension",
			filename: "README",
			want:     "README",
		},
		{
			name:     "Hidden file without extension",
			filename: ".gitignore",
			want:     "gitignore",
		},
		{
			name:     "Empty filename",
			filename: "",
			want:     "",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := GetFileExtension(tt.filename)
			if got != tt.want {
				t.Errorf("GetFileExtension(%q) = %q, want %q", tt.filename, got, tt.want)
			}
		})
	}
}
